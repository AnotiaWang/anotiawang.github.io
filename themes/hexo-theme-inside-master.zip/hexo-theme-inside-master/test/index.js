describe('hexo-theme-inside', function () {
  require('./scripts/utils');
  require('./scripts/filters');
  require('./scripts/tags');
  require('./scripts/helpers');
  require('./scripts/renderers');
});
