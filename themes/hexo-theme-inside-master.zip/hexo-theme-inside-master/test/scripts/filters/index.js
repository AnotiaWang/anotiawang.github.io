'use strict';

describe('Filters', function () {
  require('./template');
  require('./post');
});
