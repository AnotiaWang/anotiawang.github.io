'use strict';

describe('Helpers', function () {
  require('./ga');
  require('./url_trim');
  require('./structured_data');
});
