'use strict';

describe('Renderers', function () {
  require('./md');
});
